<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/molroo-ai/sdk/main/assets/logo-dark.png">
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/molroo-ai/sdk/main/assets/logo-light.png">
    <img alt="molroo" src="https://raw.githubusercontent.com/molroo-ai/sdk/main/assets/logo-light.png" width="180" />
  </picture>
</p>

# @molroo-ai/sdk

[![version](https://img.shields.io/badge/version-0.2.2-e94560)](package.json)
[![license](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.9-3178C6)](tsconfig.json)
[![tests](https://img.shields.io/badge/tests-103-brightgreen)](src/__tests__)

Thin client SDK for the [molroo](https://molroo.io) emotion engine API. Handles prompt assembly, LLM orchestration, and memory recall — so your app just calls `chat()`.

## Install

```bash
npm install @molroo-ai/sdk
```

## Quick Start

```ts
import { MolrooPersona } from '@molroo-ai/sdk';
import { createVercelAIAdapter } from '@molroo-ai/adapter-llm/vercel-ai';

const llm = createVercelAIAdapter({
  provider: 'openai',
  apiKey: process.env.OPENAI_API_KEY!,
});

const persona = await MolrooPersona.create({
  baseUrl: 'https://api.molroo.io',
  apiKey: 'mol_sk_your_api_key',
  llm,
}, {
  identity: { name: 'Sera', coreValues: ['honesty', 'warmth'] },
  personality: { O: 0.7, C: 0.6, E: 0.8, A: 0.5, N: 0.3, H: 0.6 },
});

const result = await persona.chat('Hello!');
console.log(result.text);            // "Hey! It's great to meet you..."
console.log(result.response.emotion); // { V: 0.4, A: 0.5, D: 0.2 }
```

## How It Works

```
   Your App                    SDK                          API (PersonaDO)
      |                         |                               |
      |  persona.chat(msg)      |                               |
      |------------------------>|                               |
      |                         |  POST /personas/:id/prompt-context
      |                         |------------------------------>|
      |                         |  { systemPrompt, tools }      |
      |                         |<------------------------------|
      |                         |                               |
      |                         |  LLM call (your API key)      |
      |                         |  system: systemPrompt         |
      |                         |  -> { response, appraisal }   |
      |                         |                               |
      |                         |  POST /personas/:id/perceive  |
      |                         |  { appraisal }                |
      |                         |------------------------------>|
      |                         |  { emotion, state }           |
      |                         |<------------------------------|
      |                         |                               |
      |  { text, response }     |                               |
      |<------------------------|                               |
```

1. **Get prompt context** — API builds system prompt from live emotional state (identity + personality + mood + somatic + narrative + memory)
2. **LLM call** — SDK calls your LLM with assembled prompt. Returns response text + appraisal vector.
3. **Perceive** — SDK sends appraisal to API. Engine processes emotion pipeline -> new VAD state.
4. **Post-chat** — Episode saved, reflection triggered if needed, events emitted.

The API does all emotion computation. The SDK just connects it to your LLM.

## Two LLM Modes

### Combined Mode (default)

Single LLM call returns both response text and appraisal in one `generateObject()` call:

```ts
const persona = await MolrooPersona.create({
  baseUrl, apiKey,
  llm,  // one LLM handles everything
}, personaConfig);
```

### Split Mode

Separate LLM for appraisal (cheap/fast model) and response (quality model). Appraisal runs first -> engine updates emotion -> response generated with updated emotional state:

```ts
const persona = await MolrooPersona.create({
  baseUrl, apiKey,
  llm: responseModel,      // quality model for response text
  engineLlm: appraisalModel, // cheap model for appraisal vector
}, personaConfig);
```

## MolrooPersona API

### Static Methods

| Method | Description |
|--------|-------------|
| `MolrooPersona.create(config, personaConfig)` | Create a new persona |
| `MolrooPersona.connect(config, personaId)` | Connect to an existing persona |
| `MolrooPersona.listPersonas(config)` | List all personas |

### Instance Methods

| Method | Description |
|--------|-------------|
| `chat(message, options?)` | Full LLM orchestration: prompt -> LLM -> perceive -> result |
| `perceive(message, options?)` | Send event to emotion engine (no LLM call) |
| `tick(seconds)` | Advance time (mood decay, body recovery) |
| `getState()` | Get current emotional state |
| `setEmotion(vad)` | Direct VAD override |
| `getPromptContext(suffix?, source?)` | Get server-assembled system prompt |
| `searchMemory(query, options?)` | Search episodic memory |
| `getSnapshot()` | Get full persona snapshot |
| `putSnapshot(snapshot)` | Load persona snapshot |
| `patch(config)` | Update persona config |
| `destroy()` | Soft-delete the persona |
| `restore()` | Restore a soft-deleted persona |

### Config

```ts
interface MolrooPersonaConfig {
  baseUrl: string;                      // API URL (e.g. 'https://api.molroo.io')
  apiKey: string;                       // API key
  llm?: LLMAdapter;                     // LLM for chat (optional - emotion-only without)
  engineLlm?: LLMAdapter;              // Separate LLM for appraisal (split mode)
  memory?: MemoryAdapter | MemoryConfig; // Single adapter or split config (optional)
  recall?: RecallLimits;               // Recall limits for single adapter mode
  events?: EventAdapter;               // Event emission (optional)
}
```

## Adapters

### LLM Adapter

Required for `chat()`. Bring your own via `@molroo-ai/adapter-llm`:

```ts
import { createVercelAIAdapter } from '@molroo-ai/adapter-llm/vercel-ai';

const llm = createVercelAIAdapter({
  provider: 'openai',        // or 'anthropic', 'google'
  apiKey: process.env.OPENAI_API_KEY!,
  model: 'gpt-4o-mini',      // optional
});
```

### Memory

Client-side memory for episodic recall and semantic search. Optional — when not provided, memory recall is skipped.

**Single adapter (recommended)** — pass one `MemoryAdapter` that handles everything:

```ts
import { SqliteMemoryAdapter } from '@molroo-ai/adapter-memory/sqlite';

const persona = await MolrooPersona.create({
  baseUrl, apiKey, llm,
  memory: new SqliteMemoryAdapter({ dbPath: './memory.db' }),
  recall: { episodicLimit: 5, semanticLimit: 3 },  // optional limits
}, personaConfig);
```

Built-in `InMemoryEpisodeAdapter` also works as a single adapter (for demos/testing):

```ts
import { InMemoryEpisodeAdapter } from '@molroo-ai/sdk';

const persona = await MolrooPersona.create({
  baseUrl, apiKey, llm,
  memory: new InMemoryEpisodeAdapter(),
}, personaConfig);
```

**Split adapters (advanced)** — assemble episode store + vector search separately:

```ts
const persona = await MolrooPersona.create({
  baseUrl, apiKey, llm,
  memory: {
    episodes: episodeStore,
    semantic: vectorStore,
    embedding: embeddingProvider,
    recall: { episodicLimit: 5, semanticLimit: 3 },
  },
}, personaConfig);
```

### Events

Optional event emission for logging, webhooks, or custom integrations:

```ts
import { ConsoleEventAdapter, WebhookEventAdapter } from '@molroo-ai/sdk';

// Console logging
const events = new ConsoleEventAdapter();

// Webhook
const events = new WebhookEventAdapter({ url: 'https://...', secret: '...' });
```

## Persona Generation

Generate a complete persona config from a description using LLM:

```ts
import { generatePersona } from '@molroo-ai/sdk';

const result = await generatePersona(llm, {
  name: 'Sera',
  description: 'A cheerful companion who loves music',
});
// result.config -> full PersonaConfigData
```

## Build & Test

```bash
npm run build      # tsc -> dist/cjs + dist/esm
npm run test       # Vitest (103 tests)
npm run lint       # ESLint
npm run gen:types  # openapi-typescript -> src/generated/api.d.ts
npm run docs       # TypeDoc -> SDK API reference
```

## Links

- [Documentation](https://docs.molroo.io)
- [Dashboard](https://molroo.io/dashboard)
- [API Reference](https://api.molroo.io/docs)

## License

MIT
