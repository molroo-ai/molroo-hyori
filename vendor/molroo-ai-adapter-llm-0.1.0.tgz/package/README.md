<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/logo-dark.png">
    <source media="(prefers-color-scheme: light)" srcset="assets/logo-light.png">
    <img alt="molroo" src="assets/logo-light.png" width="180" />
  </picture>
</p>

# @molroo-ai/adapter-llm

[![version](https://img.shields.io/badge/version-0.1.0-e94560)](package.json)
[![license](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3+-3178C6)](https://www.typescriptlang.org/)

LLM adapters for the [molroo](https://molroo.io) emotion simulation platform.

Provides the `LLMAdapter` interface and provider implementations. Currently ships with a **Vercel AI SDK** adapter supporting OpenAI, Anthropic, and Google Vertex AI.

## Installation

```bash
npm install @molroo-ai/adapter-llm
```

Install the provider SDK you need:

```bash
# OpenAI
npm install ai @ai-sdk/openai

# Anthropic
npm install ai @ai-sdk/anthropic

# Google Vertex AI
npm install ai @ai-sdk/google-vertex
```

## Usage

```typescript
import { createVercelAIAdapter } from '@molroo-ai/adapter-llm/vercel-ai';
import { MolrooWorld } from '@molroo-ai/sdk';

const llm = createVercelAIAdapter({
  provider: 'openai',
  apiKey: process.env.OPENAI_API_KEY!,
  model: 'gpt-4o-mini', // optional, defaults per provider
});

const world = await MolrooWorld.create({
  baseUrl: 'https://api.molroo.io',
  apiKey: 'your_api_key',
  llm,
}, setup);

const result = await world.chat('Sera', 'Hello!');
```

## Subpath Exports

| Import Path | Export |
|---|---|
| `@molroo-ai/adapter-llm` | `LLMAdapter`, `LLMPrompt`, `ChatMessage` (types) |
| `@molroo-ai/adapter-llm/vercel-ai` | `VercelAIAdapter`, `createVercelAIAdapter`, `VercelAIConfig` |

## LLMAdapter Interface

```typescript
interface LLMAdapter {
  generate(prompt: LLMPrompt, schema: object, message: string): Promise<any>;
  generateText(prompt: LLMPrompt, message: string): Promise<string>;
}
```

- `generate()` — structured output (JSON schema constrained)
- `generateText()` — plain text generation

## Vercel AI Config

```typescript
interface VercelAIConfig {
  provider: 'openai' | 'anthropic' | 'vertex';
  apiKey: string;
  model?: string;       // Provider-specific model ID
  baseUrl?: string;     // For OpenAI-compatible APIs (Groq, Kimi, etc.)
  projectId?: string;   // For Vertex AI
  location?: string;    // For Vertex AI
}
```

## License

MIT
